import itertools
import threading
import time

from progress.bar import IncrementalBar

from cnvrgv2.utils.converters import convert_bytes


# TODO: This whole file should be converted to some custom CnvrgProgressBar class


def init_progress_bar_for_cli(name, total_files_size, ready=True, spinner_text=""):
    """
    Inits a progress bar for cli purposes. Adds the unit to use and a mutex to the progress bar object
    @param name: Name of the progress bar
    @param total_files_size: total size of files to handle in the progress bar
    @param ready: Is progress bar fully initiated, default true
    @param spinner_text: Text to use as a base for the spinner while the progress bar is not ready
    @return: The progress bar object
    """
    total_files_size, unit = convert_bytes(total_files_size)
    progress_bar = IncrementalBar(max=total_files_size, suffix='%(index).2f / %(max).2f ' + unit)

    # When sending the name to the Bar object it prints the name during the init.
    # Changing the bar prefix instead fixed it
    progress_bar.bar_prefix = name + progress_bar.bar_prefix

    progress_bar.ready = ready
    progress_bar.pending_value = 0  # Value that should have been added while the progress was not ready
    progress_bar.unit = unit
    progress_bar.mutex = threading.Lock()
    progress_bar.last_next_call = None
    progress_bar.throttled_next_interval = 1  # in seconds
    progress_bar.throttled_next = throttled_next(progress_bar)
    progress_bar.spinner_running = threading.Event()
    progress_bar.spinner_thread = threading.Thread(target=generate_spinner(progress_bar, spinner_text))
    progress_bar.finish_init = get_finish_init_func(progress_bar)

    if not ready:
        progress_bar.spinner_running.set()
        progress_bar.spinner_thread.start()

    return progress_bar


def throttled_next(self):
    def custom_next(progress):
        if not self.ready:
            self.pending_value += progress
            return

        with self.mutex:
            current_time = time.time()
            progress_to_add = progress + self.pending_value
            self.pending_value = 0

            if self.last_next_call is None \
               or current_time > self.last_next_call + self.throttled_next_interval\
               or self.index + progress_to_add >= self.max:
                self.next(progress_to_add)
                self.last_next_call = current_time
            else:
                self.index = self.index + progress_to_add

    return custom_next


def generate_spinner(self, message=""):
    spinner_icons = [message+".", message+"..", message+"..."]

    def loader():
        with self.mutex:
            spinner_icons_iterator = itertools.cycle(spinner_icons)
            previous_line_length = 0
            while True:
                if not self.spinner_running.is_set():
                    break
                spinner_icon = next(spinner_icons_iterator)
                lines_diff = previous_line_length - len(spinner_icon)

                if lines_diff > 0:
                    # Go 1 char back, write empty char, go 1 char back == Backspace :)
                    print("\b \b" * lines_diff, end="", flush=True)

                print(end="\r")  # Go to line start
                print(spinner_icon, end="", flush=True)
                previous_line_length = len(spinner_icon)
                time.sleep(0.5)

            print("\b \b" * previous_line_length, end="", flush=True)  # Clear loader last line

    return loader


def get_finish_init_func(self):
    def finish_init(total_size):
        converted_total_size, _ = convert_bytes(total_size, unit=self.unit)
        self.max = converted_total_size
        self.ready = True
        # Stop the spinner
        self.spinner_running.clear()
        self.spinner_thread.join()
        # Update the progress bar with pending progress that was gathered while the total_size was calculated
        self.throttled_next(0)

    return finish_init


