CVC_STORES_BASE = "v1/stores/"
CVC_STORE_BASE = "v1/stores/{0}"

CVC_COMMITS_BASE = "v1/stores/{0}/commits/"
CVC_COMMIT_BASE = "v1/stores/{0}/commits/{1}"

CVC_FILE_CHUNKS_BASE = "v1/stores/{0}/commits/{1}/file-chunks"
CVC_FILE_CHUNK_BASE = "v1/stores/{0}/commits/{1}/file-chunks/{2}"
